package com.toyproject.board.web.dto;

import lombok.Data;

@Data
public class CommentSaveDto {

    private Long postId;
    private String content;
}
