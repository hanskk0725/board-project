package com.toyproject.board.web.session;

public abstract class SessionConst {

    public static final String LOGIN_USER = "loginUser";
}
