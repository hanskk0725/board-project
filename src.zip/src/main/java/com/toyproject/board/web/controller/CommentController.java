package com.toyproject.board.web.controller;

import com.toyproject.board.domain.entity.Comment;
import com.toyproject.board.domain.entity.User;
import com.toyproject.board.domain.service.CommentService;
import com.toyproject.board.web.argumentResolver.Login;
import com.toyproject.board.web.dto.CommentDto;
import com.toyproject.board.web.dto.CommentSaveDto;
import com.toyproject.board.web.dto.PostDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class CommentController {

    private final CommentService commentService;

    /**
     *  content, writer, createAt
     *  넘어오는 commentsDto -> comments로 변경
     */
    @PostMapping("/comments")
    public String addComment(@Validated @ModelAttribute CommentSaveDto commentSaveDto,
                             BindingResult bindingResult, @Login User user,
                             @ModelAttribute PostDto post) {
        if(bindingResult.hasErrors()) {
            return "redirect:/posts/" + commentSaveDto.getPostId();
        }

        commentService.saveComment(post.getId(), user.getId(), commentSaveDto);

        return "redirect:/posts/" + commentSaveDto.getPostId();
    }
}
